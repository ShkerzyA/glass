<?php

class YiiAdminButtonColumn extends CButtonColumn 
{
    public function createActionUrl($action,$pk)
    {
   
    }
}
