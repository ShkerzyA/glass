<?php

return array(
	'Пожалуйста, исправьте ошибки, указанные ниже.' => 'Please, fix errors below.',
	'Изменения сохранены. Можете создать новую запись.' => 'Changes saved. You can add new entry.',
	'Сохранить и создать новую запись' => 'Save and add another',
	'Пожалуйста, укажите пароль.' => 'Please, enter password.',
	'Сохранить и редактировать' => 'Save and countinue editing',
	'Изменения сохранены.' => 'Changes saved',
	'Удалить запись ID ' => 'Delete entry ID',
	'Администрирование' => 'Administration',
	'Запись создана.' => 'Entry created',
	'Список Моделей' => 'Models List',
	'Редактировать' => 'Edit',
	'Сохранить' => 'Save',
	'Изменить' => 'Change',
	'Удалить' => 'Delete',
	'Главная' => 'Home',
	'Создать' => 'Create',
	'Выход' => 'Logout',
	'Вход' => 'Enter',
);







